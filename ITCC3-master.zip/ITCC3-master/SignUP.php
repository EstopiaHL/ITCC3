<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Laundry palace data entry</title>
   </head>
   <body>
      <center>
         <h1>Storing Form data in Database</h1>
         <form action="SignUPEngine.php" method="post">
<p>
               <label for="firstName">Username:</label>
               <input type="text" name="first_name" id="firstName">
            </p>
             
<p>
               <label for="lastName">Password:</label>
               <input type="text" name="last_name" id="lastName">
            </p>

            <input type="submit" value="Submit">
         </form>
      </center>
   </body>
</html>